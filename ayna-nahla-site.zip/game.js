(function(){
  "use strict";
  var G=window.GAME, BEES=G.bees, TOTAL=BEES.length, KEY="ayna-nahla-v1";
  var $=function(id){return document.getElementById(id)};
  var hitsEl=$("hits"), countEl=$("count"), quiz=$("quiz"), qtext=$("qtext"), optsEl=$("opts"), msgEl=$("msg"), win=$("win");
  var AD="٠١٢٣٤٥٦٧٨٩";
  function ar(n){return String(n).replace(/\d/g,function(d){return AD[d]})}

  /* ---- حفظ التقدم محليًا (مع احتياط إن كان التخزين غير متاح) ---- */
  var mem=[];
  function load(){try{var v=JSON.parse(localStorage.getItem(KEY)||"[]");return Array.isArray(v)?v:[]}catch(e){return mem.slice()}}
  function save(a){mem=a.slice();try{localStorage.setItem(KEY,JSON.stringify(a))}catch(e){}}
  var done=load().filter(function(id){return BEES.some(function(b){return b.id===id})});

  /* ---- مناطق النقر نسبية لأبعاد الصورة ---- */
  var btns={};
  BEES.forEach(function(b){
    var el=document.createElement("button");
    el.type="button"; el.className="hit"; el.setAttribute("aria-label","نحلة");
    el.style.setProperty("--x",(b.x/G.imageWidth*100)+"%");
    el.style.setProperty("--y",(b.y/G.imageHeight*100)+"%");
    el.style.setProperty("--w",(b.w/G.imageWidth*100)+"%");
    el.style.setProperty("--h",(b.h/G.imageHeight*100)+"%");
    el.dataset.id=b.id;
    el.addEventListener("click",function(){openQuiz(b,el)});
    hitsEl.appendChild(el); btns[b.id]=el;
  });
  function mark(b){
    var el=btns[b.id]; el.classList.add("done"); el.tabIndex=-1;
    if(!el.dataset.ticked){
      el.dataset.ticked="1";
      var t=document.createElement("span"); t.className="tick"; t.textContent="✓"; t.dataset.for=b.id;
      t.style.setProperty("--x",(b.x/G.imageWidth*100)+"%");
      t.style.setProperty("--y",(b.y/G.imageHeight*100)+"%");
      t.style.setProperty("--h",(b.h/G.imageHeight*100)+"%");
      hitsEl.appendChild(t);
    }
  }
  function render(){
    countEl.textContent="اكتمل: "+ar(done.length)+" من "+ar(TOTAL);
    BEES.forEach(function(b){ if(done.indexOf(b.id)>-1) mark(b); });
  }

  /* ---- نص يدعم ﴿آيات﴾ بالخط القرآني ---- */
  function rich(parent,text){
    text.split(/(﴿.*?﴾)/).forEach(function(p){
      if(!p) return;
      if(p.charAt(0)==="﴿"){var s=document.createElement("span");s.className="q";s.textContent=p;parent.appendChild(s)}
      else parent.appendChild(document.createTextNode(p));
    });
  }
  function shuffle(a){for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=a[i];a[i]=a[j];a[j]=t}return a}

  /* ---- نافذة السؤال (سؤال واحد فقط في الوقت نفسه) ---- */
  var current=null, closeTimer=null, lastFocus=null, locked=false;
  function openQuiz(b,trigger){
    if(current||locked||done.indexOf(b.id)>-1||!win.hidden) return;
    current={bee:b,solved:false}; lastFocus=trigger;
    qtext.textContent=""; rich(qtext,b.q);
    optsEl.textContent=""; msgEl.textContent=""; msgEl.className="msg";
    shuffle(b.opts.map(function(t,i){return {t:t,ok:i===b.ans}})).forEach(function(o){
      var el=document.createElement("button"); el.type="button"; el.className="opt"; rich(el,o.t);
      el.addEventListener("click",function(){choose(o,el)});
      optsEl.appendChild(el);
    });
    quiz.hidden=false;
    var first=optsEl.querySelector(".opt"); if(first) first.focus({preventScroll:true});
  }
  function choose(o,el){
    if(!current||current.solved||el.disabled) return;
    if(!o.ok){
      el.classList.add("bad"); el.disabled=true;
      msgEl.className="msg bad"; msgEl.textContent="حاولي مرة أخرى";
      return;
    }
    current.solved=true;
    el.classList.add("good");
    Array.prototype.forEach.call(optsEl.children,function(c){c.disabled=true});
    msgEl.className="msg good"; msgEl.textContent="أحسنتِ!";
    var bee=current.bee;
    if(done.indexOf(bee.id)<0){ done.push(bee.id); save(done); }   // لا يُحتسب مرتين
    render();
    closeTimer=setTimeout(function(){ closeQuiz(true); },1000);
  }
  function closeQuiz(completed){
    if(closeTimer){clearTimeout(closeTimer);closeTimer=null}
    if(!current) return;
    quiz.hidden=true; current=null;
    if(lastFocus&&!lastFocus.classList.contains("done")) { try{lastFocus.focus({preventScroll:true})}catch(e){} }
    if(done.length>=TOTAL) showWin();
  }
  $("qclose").addEventListener("click",function(){closeQuiz(false)});
  quiz.addEventListener("mousedown",function(e){ if(e.target===quiz) closeQuiz(false) });

  /* ---- الاحتفال ---- */
  function showWin(){
    var c=$("confetti"); c.textContent="";
    var colors=["#3F8A5A","#2C8FB8","#F6C344","#F08AA7","#9A7BE0"];
    for(var i=0;i<46;i++){
      var p=document.createElement("i");
      p.style.left=Math.random()*100+"%"; p.style.background=colors[i%colors.length];
      p.style.animationDuration=(2.4+Math.random()*2.2)+"s"; p.style.animationDelay=(Math.random()*.8)+"s";
      c.appendChild(p);
    }
    win.hidden=false; $("again").focus({preventScroll:true});
  }
  function hideWin(){win.hidden=true}
  $("wclose").addEventListener("click",hideWin);

  /* ---- إعادة اللعب (تأكيد بنقرتين لتجنب المسح غير المقصود) ---- */
  function reset(){
    done=[]; save(done);
    Array.prototype.forEach.call(hitsEl.querySelectorAll(".tick"),function(t){t.remove()});
    BEES.forEach(function(b){var el=btns[b.id];el.classList.remove("done");el.tabIndex=0;delete el.dataset.ticked});
    render(); hideWin();
  }
  var rb=$("restart"), rt=null;
  rb.addEventListener("click",function(){
    if(done.length===0){return}
    if(rb.classList.contains("confirm")){clearTimeout(rt);rb.classList.remove("confirm");rb.textContent="العبِي مجددًا";reset();return}
    rb.classList.add("confirm"); rb.textContent="اضغطي للتأكيد";
    rt=setTimeout(function(){rb.classList.remove("confirm");rb.textContent="العبِي مجددًا"},3000);
  });
  $("again").addEventListener("click",reset);

  /* ---- ملء الشاشة ---- */
  var root=document.documentElement, fsBtn=$("fs");
  var reqFS=root.requestFullscreen||root.webkitRequestFullscreen;
  var exitFS=document.exitFullscreen||document.webkitExitFullscreen;
  if(!reqFS){fsBtn.hidden=true}
  fsBtn.addEventListener("click",function(){
    var on=document.fullscreenElement||document.webkitFullscreenElement;
    try{ on? exitFS.call(document) : reqFS.call(root); }catch(e){}
  });
  function fsLabel(){var on=document.fullscreenElement||document.webkitFullscreenElement;fsBtn.textContent=on?"⛶ خروج":"⛶ ملء الشاشة"}
  document.addEventListener("fullscreenchange",fsLabel); document.addEventListener("webkitfullscreenchange",fsLabel);

  /* ---- Escape: يغلق النافذة دون احتساب السؤال ---- */
  document.addEventListener("keydown",function(e){
    if(e.key!=="Escape") return;
    if(!win.hidden){hideWin();return}
    if(current){ closeQuiz(false) }
  });

  render();
  if(done.length>=TOTAL) showWin();
})();
